/**
 * 流程管理Javascript
 * 
 * @author HenryYan
 */
$(function() {
	$('#redeploy').button().click(redeploy);
});